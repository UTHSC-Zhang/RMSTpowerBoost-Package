## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
   message = FALSE,
      # eval = FALSE,
   cache = TRUE,
   cache.path = "cache/RMSTpowerBoost-Main/",
   warning = FALSE,
   comment = NA,
   fig.align = 'center',
   fig.width = 7,
   fig.height = 5,
   table.width = "100%",
   table.align = "center",
   collapse = TRUE
)
packages = c("survival", "dplyr", "tidyr", "knitr", "ggplot2", "mgcv", "kableExtra")
lapply(packages, require, character.only = TRUE)

library(RMSTpowerBoost)

## ----veteran_data_prep, echo=FALSE--------------------------------------------
vet <- veteran %>%
  mutate(
    arm = ifelse(trt == 1, 0, 1),
    status = status
  )
head(vet)

## ----veteran_power_calc-------------------------------------------------------
power_results_vet <- rmst.power(
  Surv(time, status) ~ karno,
  data         = vet,
  arm          = "arm",
  sample_sizes = c(100, 150, 200, 250),
  L            = 270
)

## ----veteran_table_plot, echo=FALSE-------------------------------------------

kbl(power_results_vet$results_data , caption = "Power Analysis for Veteran Dataset") %>%
 kable_styling(bootstrap_options = "striped", full_width = FALSE, position = "center")


## ----veteran_ss_calc----------------------------------------------------------
ss_results_vet <- rmst.ss(
  Surv(time, status) ~ karno,
  data         = vet,
  arm          = "arm",
  target_power = 0.40,
  L            = 365,
  n_start = 1000, n_step = 250, max_n = 5000
)

## ----veteran_ss_table, echo=FALSE---------------------------------------------

kbl(ss_results_vet$results_summary, caption = "Estimated Effect from Reference Data") %>%
 kable_styling(bootstrap_options = "striped", full_width = FALSE, position = "center")

ss_results_vet$results_plot +
  theme_bw(base_size = 14)


## ----linear_boot_example------------------------------------------------------
power_boot_vet <- rmst.power(
  Surv(time, status) ~ karno,
  data         = vet,
  arm          = "arm",
  sample_sizes = c(150, 200, 250),
  L            = 365,
  type         = "boot",
  n_sim        = 50
)

## ----echo=FALSE---------------------------------------------------------------
power_boot_vet$results_plot

## -----------------------------------------------------------------------------
ss_boot_vet <- rmst.ss(
  Surv(time, status) ~ karno,
  data         = vet,
  arm          = "arm",
  target_power = 0.5,
  L            = 180,
  type         = "boot",
  n_sim        = 100,
  patience     = 5
)

## ----echo=FALSE---------------------------------------------------------------

ss_boot_vet$results_plot +
  theme_bw(base_size = 14)

## ----colon_data_prep, echo=FALSE----------------------------------------------
colon_death <- colon %>%
  filter(etype == 2) %>%
  select(time, status, rx, extent) %>%
  na.omit() %>%
  mutate(
    arm = ifelse(rx == "Obs", 0, 1),
    status = status,
    strata = factor(extent)
  )
head(colon_death)

## ----colon_ss_calc------------------------------------------------------------
ss_results_colon <- rmst.ss(
  Surv(time, status) ~ 1,
  data         = colon_death,
  arm          = "arm",
  strata       = "strata",
  strata_type  = "additive",
  target_power = 0.60,
  L            = 1825,
  n_start = 100, n_step = 100, max_n = 10000
)

## ----colon_ss_table, echo=FALSE-----------------------------------------------

kbl(ss_results_colon$results_summary , caption = "Estimated Effect from Reference Data") %>%
 kable_styling(bootstrap_options = "striped", full_width = FALSE, position = "center")
final_n_colon <- ss_results_colon$results_data$Required_N_per_Stratum
power_at_final_n_colon <- ss_results_colon$results_plot$data %>%
  filter(N_per_Stratum == final_n_colon) %>% pull(Power)

ss_results_colon$results_plot


## ----additive_power_calc------------------------------------------------------
power_results_colon <- rmst.power(
  Surv(time, status) ~ 1,
  data         = colon_death,
  arm          = "arm",
  strata       = "strata",
  strata_type  = "additive",
  sample_sizes = c(1000, 3000, 5000),
  L            = 1825
)


## ----additive_power_table_plot, echo=FALSE------------------------------------
kbl(power_results_colon$results_data, caption = "Power for Additive Stratified Colon Trial") %>%
 kable_styling(bootstrap_options = "striped", full_width = FALSE, position = "center")

power_results_colon$results_plot +
  geom_hline(yintercept = 0.8, linetype = "dashed", color = "red") +
  labs(title = "Power Curve for Additive Stratified Model") +
  theme_bw(base_size = 14)

## ----ms_power_analytical_example----------------------------------------------
power_ms_analytical <- rmst.power(
  Surv(time, status) ~ 1,
  data         = colon_death,
  arm          = "arm",
  strata       = "strata",
  strata_type  = "multiplicative",
  sample_sizes = c(300, 400, 500),
  L            = 1825
)

## ----echo=FALSE---------------------------------------------------------------

kbl(power_ms_analytical$results_data, caption = "Power for Multiplicative Stratified Model") %>%
  kable_styling(bootstrap_options = "striped", full_width = FALSE, position = "center")

## ----ms_ss_analytical_example-------------------------------------------------
ms_ss_results_colon <- rmst.ss(
  Surv(time, status) ~ 1,
  data         = colon_death,
  arm          = "arm",
  strata       = "strata",
  strata_type  = "multiplicative",
  target_power = 0.6,
  L            = 1825
)

## ----echo=FALSE---------------------------------------------------------------

kbl(ms_ss_results_colon$results_summary, caption = "Sample Size for Multiplicative Stratified Model") %>%
  kable_styling(bootstrap_options = "striped", full_width = FALSE, position = "center")

ms_ss_results_colon$results_plot +
   theme_bw(base_size = 14)

## ----ms_power_boot_example----------------------------------------------------
power_ms_boot <- rmst.power(
  Surv(time, status) ~ 1,
  data           = colon_death,
  arm            = "arm",
  strata         = "strata",
  strata_type    = "multiplicative",
  sample_sizes   = c(100, 300, 500),
  L              = 1825,
  type           = "boot",
  n_sim          = 30,
  parallel.cores = 1
)

## ----echo=FALSE---------------------------------------------------------------
kbl(power_ms_boot$results_summary, caption = "Power for Multiplicative Stratified Model (Bootstrap)") %>%
  kable_styling(bootstrap_options = "striped", full_width = FALSE, position = "center")
power_ms_boot$results_plot

## ----ms_ss_boot_example-------------------------------------------------------
ss_ms_boot <- rmst.ss(
  Surv(time, status) ~ 1,
  data           = colon_death,
  arm            = "arm",
  strata         = "strata",
  strata_type    = "multiplicative",
  target_power   = 0.75,
  L              = 1825,
  type           = "boot",
  n_sim          = 30,
  n_start        = 100,
  n_step         = 50,
  patience       = 4,
  parallel.cores = 1
)

## ----echo=FALSE---------------------------------------------------------------

kbl(ss_ms_boot$results_summary, caption = "Sample Size for Multiplicative Stratified Model (Bootstrap)") %>%
  kable_styling(bootstrap_options = "striped", full_width = FALSE, position = "center")

## ----gbsg_data_prep, echo=FALSE-----------------------------------------------
gbsg_prepared <- gbsg %>%
   mutate(
      arm = ifelse(hormon == "no", 0, 1)
   )
head(gbsg_prepared)

## ----gbsg_power_calc----------------------------------------------------------
power_gam <- rmst.power(
  Surv(rfstime, status) ~ s(pgr),
  data           = gbsg_prepared,
  arm            = "arm",
  sample_sizes   = c(50, 200, 400),
  L              = 2825,
  n_sim          = 50,
  parallel.cores = 1
)

print(power_gam$results_plot)

## -----------------------------------------------------------------------------
ss_gam <- rmst.ss(
  Surv(rfstime, status) ~ s(pgr),
  data           = gbsg_prepared,
  arm            = "arm",
  target_power   = 0.95,
  L              = 182,
  n_sim          = 50,
  patience       = 5,
  parallel.cores = 1
)

## ----echo=FALSE---------------------------------------------------------------
ss_gam$results_plot +
   theme_bw(base_size = 14)

## ----mgus2_data_prep, echo=FALSE----------------------------------------------
mgus_prepared <- mgus2 %>%
   mutate(
      status = ifelse(pstat == 1, 1, 0),   # 1 = event, 0 = censored
      arm = ifelse(sex == "M", 1, 0)       # treatment indicator
   ) %>%
   rename(time = futime)
head(mgus_prepared)

## ----dc_power_calc------------------------------------------------------------
dc_power_results <- rmst.power(
  Surv(time, status) ~ age,
  data         = mgus_prepared,
  arm          = "arm",
  sample_sizes = c(100, 250, 500),
  L            = 120,
  dep_cens     = TRUE,
  alpha        = 0.05
)

## ----echo=FALSE---------------------------------------------------------------
kbl(dc_power_results$results_summary,
    caption = "Analytic Power Analysis under Covariate-Dependent Censoring") %>%
  kable_styling(bootstrap_options = "striped",
                full_width = FALSE, position = "center")

dc_power_results$results_plot

## ----mgus2_ss_calc------------------------------------------------------------
ss_dc_mgus <- rmst.ss(
  Surv(time, status) ~ age,
  data         = mgus_prepared,
  arm          = "arm",
  target_power = 0.80,
  L            = 120,
  dep_cens     = TRUE,
  alpha        = 0.05,
  n_start = 100, n_step = 50, max_n = 5000
)

## ----mgus2_table, echo=FALSE--------------------------------------------------
kbl(ss_dc_mgus$results_summary,
    caption = "Estimated RMST Difference from Reference Data") %>%
  kable_styling(bootstrap_options = "striped",
                full_width = FALSE, position = "center")

ss_dc_mgus$results_plot + theme_bw(base_size = 14)

## ----eval=FALSE---------------------------------------------------------------
# RMSTpowerBoost::run_app()

